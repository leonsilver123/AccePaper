// @deepseek-ai/dsh-research-team — T19-B executor registry (real-tool integration).
//
// The single, auditable map of every one of the 16 pipeline steps → its executor
// + the truthfulness classification of that executor. This is the T19-B upgrade
// over T19-A: instead of 1 real tool + 15 deterministic fixtures, this registry
// wires as many REAL research tools as are feasible and labels every remaining
// step explicitly as a fixture.
//
// Discipline (spec §7, frozen):
//  - kind is declared honestly and matches the implementation (real_tool /
//    mock_external / fixture). mock_external = the tool function runs for real
//    but its data source is a synthetic/mock adapter (never presented as real
//    literature/science; the report marks it mock_external).
//  - Every artifact produced by a real_tool / mock_external executor is stamped
//    with a `__producer` + `__kind` field so a test can prove (from the artifact
//    alone) that the real tool actually ran — no claim of real execution rests on
//    the registry's existence alone.
//  - This file does NOT re-implement the core gate, does NOT reinterpret an
//    outcome, does NOT add a StepStatus, does NOT auto-approve E2, and preserves
//    the core runStep atomicity (rollback / new-attempt / timeout / error /
//    artifact) — it only supplies executors consumed by the drive layer via core
//    runStep.
//
// Real tools are consumed from the `@deepseek-ai/dsh-research-tools` package
// (declared dependency — spec §0 states team already depends on tools). No tools
// src is modified. All core engine functions used here come from the public
// `@deepseek-ai/dsh-research-core` entry.

import type { StepDefinition } from '@deepseek-ai/dsh-research-core'
import {
  constructClaim,
  createMockAblationExecutor,
  mockLiteratureSearchAdapter,
  renderFigure,
  renderThreeLineTable,
  runAblation,
  runLiteratureSearch,
} from '@deepseek-ai/dsh-research-tools'

/** Truthfulness classification of a step executor (spec §1). */
export type Truthfulness = 'real_tool' | 'fixture' | 'mock_external'

/** Fixed caller-injected timestamp so two E2E runs are byte-for-byte deterministic. */
export const FIXED_TS = 1_700_000_000_000

/**
 * Cross-step mutable scratch populated by executors so downstream gate verdicts
 * (the C-channel) can reference the claim / prediction the real tools produced.
 */
export interface RunContext {
  /** The canonical falsifiable prediction text (set by A2-claim executor). */
  predictionText: string
  /** The claim id (set by A2-claim executor; matches the experiment fixture key). */
  claimId: string
  /** Human-readable claim reference (set by A2-claim executor). */
  claimRef: string
  /** The fixed timestamp used across the run (set by the driver). */
  timestamp: number
}

/** Context handed to every registry executor (drive layer adapts core's StepExecContext). */
export interface ExecCtx {
  readonly runId: string
  readonly stepId: string
  readonly attemptId: number
  /** Cooperative-cancellation signal forwarded from core runStep. */
  readonly signal?: AbortSignal
  /** Read an upstream-produced artifact value (verified satisfied by canStart). */
  readonly getInput: (slug: string) => unknown
  /** Shared cross-step scratch (claim / prediction wiring). */
  readonly runCtx: RunContext
}

/** A registry entry: how one step is executed + its truthfulness. */
export interface StepExecutorEntry {
  readonly stepId: string
  readonly kind: Truthfulness
  /** Producer brand, e.g. 'literature-search@0.1.2-alpha.4' or 'fixture:landscape'. */
  readonly producer: string
  readonly executor: (ctx: ExecCtx) => Promise<Record<string, unknown>> | Record<string, unknown>
  /** E2-submit stops at the human gate (completeStep → 'gated'); no executor runs. */
  readonly humanGateStop?: boolean
}

/**
 * Stamp an artifact value with producer provenance. The wrapper is a plain
 * (non-frozen) object so the `__producer` / `__kind` fields are visible to tests
 * as artifact-level evidence that the real tool actually executed. Frozen tool
 * artifacts are spread (their values copied) so the wrapper is writable.
 */
export function tagArtifact(
  value: unknown,
  producer: string,
  kind: Truthfulness,
): Record<string, unknown> {
  if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
    return { ...(value as Record<string, unknown>), __producer: producer, __kind: kind }
  }
  return { value, __producer: producer, __kind: kind }
}

function realProducer(toolId: string, version: string): string {
  return `${toolId}@${version}`
}

// ── Producer brands (mirror the tools' own version constants) ───────────────────
const A1_PRODUCER = realProducer('literature-search', '0.1.2-alpha.4')
const A2_PRODUCER = realProducer('claim-construct', '1.0.0')
const B3_PRODUCER = realProducer('ablation', '0.1.2-alpha.4')
const D1_PRODUCER = realProducer('figure', '0.1.2-alpha.4')
const E1_PRODUCER = realProducer('three-line-table', '0.1.2-alpha.4')

// Canonical claim + prediction that matches a KEEP-path row in the team's
// experiment fixture table (`experiment/fixture.ts`) so the C-channel adjudicates
// to `passed` on the happy path.
const CANONICAL_CLAIM_ID = 'mock-claim-001'
const CANONICAL_CLAIM_REF = 'adaptive signal control reduces peak-hour delay'
const CANONICAL_PREDICTION = 'peak-hour delay falls by at least 8% under adaptive control'

/** Step → declared output slugs (team-local projection of the frozen 16-step graph). */
const STEP_OUTPUTS: Readonly<Record<string, ReadonlyArray<string>>> = {
  'A1-landscape': ['landscape-map', 'gap-list'],
  'A2-claim': ['claim', 'falsifiable-prediction'],
  'A3-agenda': ['agenda', 'contribution-list'],
  'A4-venue': ['venue', 'venue-scope'],
  'B1-method': ['method-spec', 'method-predictions'],
  'B2-data': ['dataset', 'data-profile'],
  'B3-baseline': ['baseline-results', 'sota-comparison'],
  'C1-mvp': ['mvp-results'],
  'C2-trinity-loop': ['converged-verdict'],
  'C3-boundary': ['ablation-results', 'boundary-map'],
  'D1-figure-map': ['figure-plan'],
  'D2-framework': ['paper-outline'],
  'D3-writing': ['draft'],
  'D4-rebuttal': ['rebuttal', 'revised-draft'],
  'E1-format': ['formatted-manuscript'],
  'E2-submit': ['submission-record'],
}

// ── Real-tool executors ─────────────────────────────────────────────────────────

/** A1-landscape: real `runLiteratureSearch` over a mock literature adapter. */
function a1Executor(): Record<string, unknown> {
  const artifact = runLiteratureSearch(
    { topic: 'adaptive traffic signal control' },
    mockLiteratureSearchAdapter,
    FIXED_TS,
  )
  return {
    'landscape-map': tagArtifact(
      {
        topic: artifact.query.topic,
        outcome: artifact.outcome,
        hitCount: artifact.hits.length,
        hits: artifact.hits,
        note: 'landscape-map derived from a REAL runLiteratureSearch (mock adapter data)',
      },
      A1_PRODUCER,
      'mock_external',
    ),
    'gap-list': tagArtifact(
      {
        gaps: ['SOTA delay-reduction gap under adaptive control is unverified'],
        source: 'mock_external literature adapter',
      },
      A1_PRODUCER,
      'mock_external',
    ),
  }
}

/** A2-claim: real `constructClaim` producing a claim + falsifiable prediction. */
function a2Executor(ctx: ExecCtx): Record<string, unknown> {
  const artifact = constructClaim({
    assertion: 'Adaptive signal control reduces peak-hour delay beyond the 8% SOTA gap.',
    claimId: CANONICAL_CLAIM_ID,
    now: FIXED_TS,
    falsifiability: {
      essentialDifference: 'control policy is adaptive (RL) rather than fixed-time',
      experimentToFalsify: 'Measure peak-hour delay under adaptive control vs a fixed-time baseline.',
    },
  })
  // Wire the claim + prediction into the shared context for downstream C-gates.
  ctx.runCtx.claimId = CANONICAL_CLAIM_ID
  ctx.runCtx.claimRef = CANONICAL_CLAIM_REF
  ctx.runCtx.predictionText = CANONICAL_PREDICTION
  return {
    claim: tagArtifact(artifact.claim, A2_PRODUCER, 'real_tool'),
    'falsifiable-prediction': tagArtifact(
      {
        text: CANONICAL_PREDICTION,
        ref: CANONICAL_CLAIM_ID,
        supportStatus: artifact.claim.supportStatus,
      },
      A2_PRODUCER,
      'real_tool',
    ),
  }
}

/** B3-baseline: real `runAblation` with an injected mock executor (fixture data). */
function b3Executor(): Record<string, unknown> {
  const definition = {
    baselineIdentity: 'fixed-time',
    variantIdentity: 'adaptive-rl',
    removedOrReplacedComponents: [
      { component: 'phase-plan', action: 'replaced', replacement: 'adaptive-rl' },
    ],
    dataset: { version: 'v1', split: 'train', seed: 7 },
    metric: { name: 'delay', direction: 'lower-is-better' },
    repetitions: 4,
  }
  const artifact = runAblation(definition, createMockAblationExecutor(), FIXED_TS)
  return {
    'baseline-results': tagArtifact(
      {
        ranRuns: artifact.runs.length,
        counts: artifact.counts,
        aggregate: artifact.aggregate,
        note: 'baseline-results from a REAL runAblation (mock executor measurements)',
      },
      B3_PRODUCER,
      'mock_external',
    ),
    'sota-comparison': tagArtifact(
      {
        baseline: 'fixed-time',
        variant: 'adaptive-rl',
        note: 'synthetic SOTA comparison (mock_external)',
      },
      B3_PRODUCER,
      'mock_external',
    ),
  }
}

/** D1-figure-map: real `renderFigure` producing byte-valid SVG + PNG. */
function d1Executor(): Record<string, unknown> {
  const artifact = renderFigure(
    {
      kind: 'bar',
      title: 'Convergence Trace',
      width: 320,
      height: 240,
      series: [{ name: 'ablation', values: [3, 7, 5, 9, 6] }],
      tokens: { palette: ['#1f77b4'] },
      seed: 7,
    },
    FIXED_TS,
  )
  return {
    'figure-plan': tagArtifact(
      {
        svgByteLength: artifact.svg.byteLength,
        pngByteLength: artifact.png.byteLength,
        svgPreview: String(artifact.svg.content).slice(0, 80),
        note: 'figure-plan derived from a REAL renderFigure SVG+PNG artifact',
      },
      D1_PRODUCER,
      'real_tool',
    ),
  }
}

/** E1-format: real `renderThreeLineTable` rendering a manuscript results table. */
function e1Executor(): Record<string, unknown> {
  const artifact = renderThreeLineTable(
    {
      title: 'Peak-hour Delay (synthetic table component)',
      columns: [
        { header: 'Method', decimals: 0 },
        { header: 'Delay (s)', decimals: 1, metricDirection: 'lower-is-better' },
      ],
      rows: [
        [
          { kind: 'text', text: 'Adaptive' },
          { kind: 'number', value: 7.2 },
        ],
        [
          { kind: 'text', text: 'Fixed-time' },
          { kind: 'number', value: 9.1 },
        ],
      ],
    },
    'markdown',
    FIXED_TS,
  )
  return {
    'formatted-manuscript': tagArtifact(
      {
        tableMarkdown: artifact.render.text,
        bindingHash: artifact.bindingHash,
        note: 'formatted-manuscript rendered by REAL renderThreeLineTable (three-line table artifact; part of the E1 format step)',
      },
      E1_PRODUCER,
      'real_tool',
    ),
  }
}

/** Default deterministic fixture executor for any non-real step. */
function fixtureExecutor(stepId: string, label: string): (ctx: ExecCtx) => Record<string, unknown> {
  const producer = `fixture:${label}`
  return () => {
    const slugs = STEP_OUTPUTS[stepId] ?? []
    const out: Record<string, unknown> = {}
    for (const slug of slugs) {
      out[slug] = tagArtifact(
        {
          fixture: true,
          stepId,
          slug,
          note: 'synthetic E2E fixture artifact — NOT real literature/science/model output',
        },
        producer,
        'fixture',
      )
    }
    return out
  }
}

// ── Registry (16-step map) ──────────────────────────────────────────────────────
// kind reflects the EXECUTOR truthfulness. A step whose GATE uses the real
// trinity adjudication but whose executor is a fixture (e.g. C2) is still
// labeled 'fixture' here; its gate verdicts are real (see verdict.ts).

interface EntrySpec {
  readonly stepId: string
  readonly kind: Truthfulness
  readonly producer: string
  readonly executor?: (ctx: ExecCtx) => Record<string, unknown>
  readonly humanGateStop?: boolean
  readonly fixtureLabel?: string
}

const ENTRY_SPECS: ReadonlyArray<EntrySpec> = [
  { stepId: 'A1-landscape', kind: 'mock_external', producer: A1_PRODUCER, executor: a1Executor },
  { stepId: 'A2-claim', kind: 'real_tool', producer: A2_PRODUCER, executor: a2Executor },
  { stepId: 'A3-agenda', kind: 'fixture', producer: 'fixture:agenda', fixtureLabel: 'agenda' },
  { stepId: 'A4-venue', kind: 'fixture', producer: 'fixture:venue', fixtureLabel: 'venue' },
  { stepId: 'B1-method', kind: 'fixture', producer: 'fixture:method', fixtureLabel: 'method' },
  { stepId: 'B2-data', kind: 'fixture', producer: 'fixture:data', fixtureLabel: 'data' },
  { stepId: 'B3-baseline', kind: 'mock_external', producer: B3_PRODUCER, executor: b3Executor },
  { stepId: 'C1-mvp', kind: 'fixture', producer: 'fixture:mvp', fixtureLabel: 'mvp' },
  { stepId: 'C2-trinity-loop', kind: 'fixture', producer: 'fixture:trinity-loop', fixtureLabel: 'trinity-loop' },
  { stepId: 'C3-boundary', kind: 'fixture', producer: 'fixture:boundary', fixtureLabel: 'boundary' },
  { stepId: 'D1-figure-map', kind: 'real_tool', producer: D1_PRODUCER, executor: d1Executor },
  { stepId: 'D2-framework', kind: 'fixture', producer: 'fixture:framework', fixtureLabel: 'framework' },
  { stepId: 'D3-writing', kind: 'fixture', producer: 'fixture:writing', fixtureLabel: 'writing' },
  { stepId: 'D4-rebuttal', kind: 'fixture', producer: 'fixture:rebuttal', fixtureLabel: 'rebuttal' },
  { stepId: 'E1-format', kind: 'real_tool', producer: E1_PRODUCER, executor: e1Executor },
  { stepId: 'E2-submit', kind: 'fixture', producer: 'human-gate', humanGateStop: true },
]

function buildRegistry(): Map<string, StepExecutorEntry> {
  const map = new Map<string, StepExecutorEntry>()
  for (const spec of ENTRY_SPECS) {
    const fallback = fixtureExecutor(spec.stepId, spec.fixtureLabel ?? spec.stepId)
    map.set(spec.stepId, {
      stepId: spec.stepId,
      kind: spec.kind,
      producer: spec.producer,
      executor: spec.executor ?? fallback,
      ...(spec.humanGateStop === true ? { humanGateStop: true } : {}),
    })
  }
  return map
}

/** The authoritative 16-step executor registry (spec §1/§2). */
export const STEP_EXECUTOR_REGISTRY: ReadonlyMap<string, StepExecutorEntry> = buildRegistry()

/** Step → declared output slugs (re-exported for the drive layer). */
export const STEP_OUTPUT_MAP: Readonly<Record<string, ReadonlyArray<string>>> = STEP_OUTPUTS

/** Convenience: the canonical claim/prediction constants used by executors + verdicts. */
export const CANONICAL = {
  claimId: CANONICAL_CLAIM_ID,
  claimRef: CANONICAL_CLAIM_REF,
  prediction: CANONICAL_PREDICTION,
} as const

export type { StepDefinition }
