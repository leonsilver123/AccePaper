// @deepseek-ai/dsh-research-team — T19-B shared run/drive result types.
//
// These types are defined in team/src (tsc-checked) so both the runner modules
// and the E2E helpers/drive layer can import them without reaching outside the
// `src` root (which the team tsconfig forbids). The drive layer itself lives
// under tests/e2e/helpers (it imports core-internal `runStep`/`STEPS`, which are
// not tsc-checked there — mirroring the T19-A e2e convention).

import type { GateOutcome, StepStatus, TrinityComponent } from '@deepseek-ai/dsh-research-core'
import type { Truthfulness } from './registry.ts'

/** Per-artifact producer evidence for one step. */
export interface StepArtifactEvidence {
  readonly slug: string
  readonly producedBy: string
}

/** Outcome of driving one step (auditable; includes producer/kind evidence). */
export interface StepOutcome {
  readonly stepId: string
  readonly status: StepStatus
  readonly attemptId: number
  readonly kind: Truthfulness | 'humanGate'
  readonly producer: string
  readonly outputSlugs: ReadonlyArray<string>
  readonly artifacts: ReadonlyArray<StepArtifactEvidence>
  readonly verdicts: Readonly<Record<string, GateOutcome>>
  readonly usedRealTool: boolean
  readonly executeError?: string
}

/** Full-run result. */
export interface RunResult {
  readonly runId: string
  readonly steps: ReadonlyArray<StepOutcome>
}

/** Per-step override / scenario hooks for the driver. */
export interface DriveOptions {
  readonly domainDirection?: string
  readonly timeoutMs?: number
  readonly signal?: AbortSignal
  /** Override the executor for selected steps (recovery / fault injection). */
  readonly executorOverride?: (stepId: string) => ((ctx: import('./registry.ts').ExecCtx) => Promise<Record<string, unknown>> | Record<string, unknown>) | undefined
  /** Inject `abstained` for the given components of the given step (recovery hold). */
  readonly abstainComponents?: (stepId: string) => ReadonlyArray<TrinityComponent>
  readonly fixedTimestamp?: number
  /** Stop BEFORE driving this step (returns after its predecessors). */
  readonly stopBefore?: string
}

/** Context needed to build the gate verdicts for one step attempt. */
export interface VerdictBuildCtx {
  readonly step: import('./registry.ts').StepDefinition
  readonly attemptId: number
  readonly runCtx: import('./registry.ts').RunContext
  /** Components that should be injected as `abstained` (recovery scenario). */
  readonly abstain: ReadonlySet<TrinityComponent>
}
