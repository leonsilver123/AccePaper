// @deepseek-ai/dsh-research-team — T19-B E2E reporting.
//
// Writes the runner's auditable outputs to `.workbuddy/tmp/e2e-out-t19b/` (outside
// the version-controlled tree):
//   - run-snapshot-{happy,recovery}.json  (machine-readable StepOutcome[])
//   - e2e-report-t19b.md                  (human-readable run summary)
//   - t19a-vs-t19b.md                     (T19-A vs T19-B comparison)
//
// Every real_tool / mock_external step is reported with its producer + artifact
// evidence so a reviewer can verify (from the report alone) that the real tool
// actually executed — no claim rests solely on the registry's existence.

import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'

import type { RunResult, StepOutcome } from './types.ts'

const DEFAULT_OUT_DIR = '.workbuddy/tmp/e2e-out-t19b'

function outDirOf(override?: string): string {
  return override ? resolve(override) : resolve(process.cwd(), DEFAULT_OUT_DIR)
}

function ensureDir(dir: string): void {
  mkdirSync(dir, { recursive: true })
}

/** T19-A baseline facts (from the frozen T19-A e2e: 1 real tool + 15 fixtures). */
const T19A = {
  realToolCount: 1,
  realToolSteps: ['D1-figure-map'],
  fixtureCount: 15,
  note: 'T19-A: 1 real tool (renderFigure on D1) + 15 deterministic fixtures; E2 stops gated.',
} as const

function countKinds(steps: ReadonlyArray<StepOutcome>): { realTool: number; mockExternal: number; fixture: number; humanGate: number } {
  let realTool = 0
  let mockExternal = 0
  let fixture = 0
  let humanGate = 0
  for (const s of steps) {
    if (s.kind === 'humanGate') humanGate += 1
    else if (s.kind === 'real_tool') realTool += 1
    else if (s.kind === 'mock_external') mockExternal += 1
    else fixture += 1
  }
  return { realTool, mockExternal, fixture, humanGate }
}

function stepTableMarkdown(steps: ReadonlyArray<StepOutcome>): string {
  const rows = steps
    .map((s) => {
      const produced = s.artifacts.map((a) => `${a.slug}←${a.producedBy}`).join('; ')
      const verdicts = Object.entries(s.verdicts)
        .map(([c, o]) => `${c}:${o}`)
        .join(' ')
      return `| ${s.stepId} | ${s.kind} | ${s.producer} | ${s.status} | ${produced || '—'} | ${verdicts || '—'} |`
    })
    .join('\n')
  return [
    '| step | kind | producer | status | artifact evidence | verdicts |',
    '| --- | --- | --- | --- | --- | --- |',
    rows,
  ].join('\n')
}

function renderRunMarkdown(run: RunResult, mode: string): string {
  const counts = countKinds(run.steps)
  const totalReal = counts.realTool + counts.mockExternal
  return [
    `# T19-B E2E report (${mode})`,
    '',
    `- runId: \`${run.runId}\``,
    `- steps driven: ${run.steps.length}/16`,
    `- real_tool steps: ${counts.realTool}`,
    `- mock_external steps: ${counts.mockExternal}`,
    `- fixture steps: ${counts.fixture}`,
    `- humanGate (E2 stop): ${counts.humanGate}`,
    `- total steps with real execution (real_tool + mock_external): ${totalReal}`,
    '',
    stepTableMarkdown(run.steps),
    '',
    '## Discipline checks',
    '- E2-submit status must be `gated` (human gate, never auto-approved).',
    '- `abstained` verdicts are preserved (never coerced to passed).',
    '- Artifacts from real_tool / mock_external steps carry a `__producer` field equal to the registry producer.',
    '',
  ].join('\n')
}

/** Write the JSON snapshot + markdown summary for one run mode. Returns the paths. */
export function writeRunReport(
  run: RunResult,
  mode: 'happy' | 'recovery',
  outDirOverride?: string,
): { jsonPath: string; mdPath: string } {
  const dir = outDirOf(outDirOverride)
  ensureDir(dir)
  const jsonPath = resolve(dir, `run-snapshot-${mode}.json`)
  const mdPath = resolve(dir, `e2e-report-t19b-${mode}.md`)
  writeFileSync(jsonPath, JSON.stringify({ runId: run.runId, mode, steps: run.steps }, null, 2))
  writeFileSync(mdPath, renderRunMarkdown(run, mode))
  return { jsonPath, mdPath }
}

/**
 * Write the T19-A vs T19-B comparison report. `t19bRun` is the happy-path run.
 */
export function writeComparisonReport(
  t19bRun: RunResult,
  outDirOverride?: string,
): string {
  const dir = outDirOf(outDirOverride)
  ensureDir(dir)
  const counts = countKinds(t19bRun.steps)
  const totalReal = counts.realTool + counts.mockExternal

  const lines = [
    '# T19-A vs T19-B — real executor integration',
    '',
    '## Headline',
    '',
    `| metric | T19-A | T19-B |`,
    `| --- | --- | --- |`,
    `| real_tool steps | ${T19A.realToolCount} | ${counts.realTool} |`,
    `| mock_external steps | 0 | ${counts.mockExternal} |`,
    `| fixture steps | ${T19A.fixtureCount} | ${counts.fixture} |`,
    `| total real execution (real_tool+mock_external) | ${T19A.realToolCount} | ${totalReal} |`,
    `| E2-submit | gated (stop) | gated (stop) |`,
    '',
    '## Per-step kind (T19-B)',
    '',
    stepTableMarkdown(t19bRun.steps),
    '',
    '## Gate / audit differences',
    '',
    '- T19-A verdicts are fixture-labelled (`evidence: fixture:...`); T19-B A/C/B verdicts are',
    '  produced by the genuine adjudicators (`judgeRound`, `adjudicateClaimSupport`, core',
    "  `adjudicate('B')`) and only the B-channel anchor is a local mock_external fixture (T23 not merged).",
    '- T19-B keeps the single core gate-adjudication source (`submitGateVerdict` → `_adjudicate`);',
    '  no gate logic is re-implemented in the runner.',
    '- `abstained` verdicts hold the step at `gated` (holdReason=`gate_abstained`); they are never',
    '  auto-promoted to passed.',
    '',
    '## Failure / abstain / rollback contract (preserved)',
    '',
    '- Executor throw / timeout leaves the step `in_progress` with NO artifact written (rollback-able).',
    '- An abstained gate component holds the step at `gated`; resolution requires rollback + new',
    '  attempt (never an in-place re-submit).',
    '- E2-submit is a human gate and stops at `gated`; approval is out of scope for the automated run.',
    '',
    `## T19-A note`,
    '',
    T19A.note,
    '',
  ].join('\n')

  const path = resolve(dir, 't19a-vs-t19b.md')
  writeFileSync(path, lines)
  return path
}
