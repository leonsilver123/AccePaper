// @deepseek-ai/dsh-research-team — T19-B B-channel anchor fixture (mock_external).
//
// T23 (external anchoring fixture) is on a separate track and is NOT merged into
// this repo. Per spec §3, when T23 is unavailable we use a LOCAL anchor-fixture
// constant to synthesize a `VerificationResult` that carries an external anchor
// (original-text access + supported conclusion) so the core B-gate adjudicator
// can run for real. Every such verification is explicitly graded `mock_external`
// and NEVER presented as real literature support.

import type {
  CitationEvidence,
  ClaimId,
  CitationId,
  CitationRef,
  VerificationResult,
} from '@deepseek-ai/dsh-research-core'

/** Rule version of this local anchor fixture (distinct from T23's constants). */
export const ANCHOR_FIXTURE_RULE_VERSION = 't19b-anchor-mock-v1'

export interface AnchorVerificationSpec {
  readonly claimId: ClaimId
  readonly stepId: string
  readonly timestamp: number
}

/**
 * Build one synthetic external-anchor {@link VerificationResult}. It carries a
 * real anchor shape (original-text accessed, non-`none` method, supported
 * conclusion, no red line) so the core B-gate adjudicator (`adjudicate('B')`)
 * returns `passed`. The `method`/`sourceUri`/`contentHash` mark it as a
 * mock_external fixture — downstream must not mistake it for real verification.
 */
export function makeAnchorVerification(spec: AnchorVerificationSpec): VerificationResult {
  const ref: CitationRef = {
    kind: 'doi',
    id: `10.0000/synthetic.${spec.stepId}`,
    title: `Synthetic external anchor for ${spec.stepId} (mock_external)`,
  }
  const evidence: CitationEvidence = {
    originalTextAccessed: true,
    method: 'auto_crossref',
    locator: { page: 1 },
    excerpt: 'synthetic excerpt proving external anchoring (mock_external, not real literature)',
    accessedAt: spec.timestamp,
    sourceUri: 'mock://anchor/t19b',
    sourceVersion: ANCHOR_FIXTURE_RULE_VERSION,
    contentHash: 'deadbeef00',
    retrievedAt: new Date(spec.timestamp).toISOString(),
  }
  return {
    claimId: spec.claimId,
    citationId: `anchor-${spec.stepId}` as unknown as CitationId,
    ref,
    evidence,
    conclusion: 'supported',
    redLineTriggered: false,
    reasonCode: 'DSH_CITATION_SUPPORTED',
    timestamp: spec.timestamp,
  }
}
