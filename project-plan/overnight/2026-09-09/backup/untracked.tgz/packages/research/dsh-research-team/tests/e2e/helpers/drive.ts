/**
 * T19-B E2E — drive layer (test helper).
 *
 * Mirrors the T19-A `helpers/runner.ts` boundary: it drives the real executor
 * registry through the 16-step pipeline using the CORE engine as the single
 * authority for state + gate adjudication. Because it imports core-internal
 * `runStep` / `STEPS` (not re-exported from the public core entry), it lives
 * under `tests/e2e/helpers/` — exactly where the T19-A runner helper lives — so
 * it is exercised by vitest (esbuild, no rootDir restriction) and is NOT part of
 * the `tsc --noEmit` compile set (team tsconfig `include: ["src"]`).
 *
 * Contract (spec §3/§7): dependency guard → start → runStep(registry executor)
 * → on success build genuine gate verdicts (verdict.ts) → submitGateVerdict
 * (core `_adjudicate` is the SOLE gate adjudicator) → E2-submit stops at
 * `gated`. No gate re-implementation, no outcome reinterpretation, no new status,
 * no auto E2 approval, atomicity preserved via core runStep.
 */

import type { GateOutcome, ResearchRunStore, StepStatus, TrinityComponent } from '@deepseek-ai/dsh-research-core'
import {
  canStart,
  completeStep,
  createRun,
  getArtifact,
  getRunSnapshot,
  rollback,
  setRunInput,
  startStep,
  submitGateVerdict,
} from '@deepseek-ai/dsh-research-core'
import { appendAuditEvent, STEPS, STEP_BY_ID } from '../../../../../dsh-research-core/src/engine/state-machine.ts'
import { runStep } from '../../../../../dsh-research-core/src/engine/pipeline.ts'

import type { ExecCtx, RunContext } from '../../../src/runner/registry.ts'
import { FIXED_TS, STEP_EXECUTOR_REGISTRY } from '../../../src/runner/registry.ts'
import type { DriveOptions, RunResult, StepArtifactEvidence, StepOutcome, VerdictBuildCtx } from '../../../src/runner/types.ts'
import { buildStepVerdicts } from '../../../src/runner/verdict.ts'

void runStep // referenced via core pipeline import above

/** Drive exactly one step end-to-end (dependency guard → execute → gate → E2 stop). */
export async function driveStep(
  store: ResearchRunStore,
  runId: string,
  stepId: string,
  opts: {
    readonly runCtx: RunContext
    readonly timeoutMs?: number
    readonly signal?: AbortSignal
    readonly executorOverride?: (stepId: string) => ((ctx: ExecCtx) => Promise<Record<string, unknown>> | Record<string, unknown>) | undefined
    readonly abstainComponents?: (stepId: string) => ReadonlyArray<TrinityComponent>
  },
): Promise<StepOutcome> {
  const entry = STEP_EXECUTOR_REGISTRY.get(stepId)
  if (!entry) throw new Error(`T19B drive: no registry entry for '${stepId}'`)
  const stepDef = STEP_BY_ID.get(stepId)
  if (!stepDef) throw new Error(`T19B drive: unknown step '${stepId}'`)
  if (!canStart(store, runId, stepId)) {
    throw new Error(`T19B drive: step '${stepId}' cannot start — dependency order violated`)
  }

  const started = startStep(store, runId, stepId)
  const attemptId = started.attemptId

  // E2-submit: human gate, empty gate → completeStep leaves it 'gated' (awaiting
  // human approval). The driver NEVER auto-approves (spec §7).
  if (entry.humanGateStop) {
    const status = completeStep(store, runId, stepId)
    return {
      stepId,
      status,
      attemptId,
      kind: 'humanGate',
      producer: entry.producer,
      outputSlugs: [],
      artifacts: [],
      verdicts: {},
      usedRealTool: false,
    }
  }

  const myExec = (opts.executorOverride?.(stepId) ?? entry.executor)
  const res = await runStepImpl(store, runId, stepId, {
    executor: (coreCtx) =>
      myExec({
        runId: coreCtx.runId,
        stepId: coreCtx.stepId,
        attemptId: coreCtx.attemptId,
        ...(coreCtx.signal !== undefined ? { signal: coreCtx.signal } : {}),
        getInput: (slug: string) => getArtifact(store, runId, slug),
        runCtx: opts.runCtx,
      }),
    timeoutMs: opts.timeoutMs,
    signal: opts.signal,
  })

  // Execute did NOT succeed: step stays 'in_progress' (rollback-able), NO artifact,
  // NO gate adjudication. The caller asserts and then rolls back (recovery).
  if (res.status !== 'success') {
    return {
      stepId,
      status: 'in_progress',
      attemptId,
      kind: entry.kind,
      producer: entry.producer,
      outputSlugs: res.outputSlugs,
      artifacts: [],
      verdicts: {},
      usedRealTool: entry.kind !== 'fixture',
      executeError: res.error?.message,
    }
  }

  // Gate phase — build genuine verdicts and submit via core (single adjudication source).
  const verdicts: Record<string, GateOutcome> = {}
  if (stepDef.gate.length > 0) {
    const comps = opts.abstainComponents?.(stepId) ?? []
    const vctx: VerdictBuildCtx = {
      step: stepDef,
      attemptId,
      runCtx: opts.runCtx,
      abstain: new Set(comps),
    }
    const built = buildStepVerdicts(vctx)
    for (const v of built) {
      submitGateVerdict(store, runId, stepId, v)
      appendAuditEvent(store, runId, 'gate-verdict', stepId, attemptId, {
        t19b: true,
        component: v.component,
        outcome: v.outcome,
        evidence: v.evidence,
      })
      verdicts[v.component] = v.outcome
    }
  }

  const snap = getRunSnapshot(store, runId)
  const stepSnap = snap.steps[stepId]
  const status: StepStatus = stepSnap.status

  const artifacts: StepArtifactEvidence[] = []
  for (const slug of stepDef.outputs) {
    const value = getArtifact(store, runId, slug)
    const producedBy =
      value !== null && typeof value === 'object' && !Array.isArray(value)
        ? (value as Record<string, unknown>).__producer
        : undefined
    artifacts.push({
      slug,
      producedBy: typeof producedBy === 'string' ? producedBy : entry.producer,
    })
  }

  return {
    stepId,
    status,
    attemptId,
    kind: entry.kind,
    producer: entry.producer,
    outputSlugs: stepDef.outputs,
    artifacts,
    verdicts,
    usedRealTool: entry.kind !== 'fixture',
  }
}

/** Build a fresh cross-step context (claim / prediction wiring) for a run. */
export function createRunContext(timestamp: number = FIXED_TS): RunContext {
  return { predictionText: '', claimId: '', claimRef: '', timestamp }
}

/**
 * Drive a full 16-step run. Returns the per-step outcomes. `stopBefore` halts
 * before the named step (used by recovery scenarios to inject faults mid-run).
 */
export async function runT19B(
  store: ResearchRunStore,
  opts: DriveOptions = {},
): Promise<RunResult> {
  const timestamp = opts.fixedTimestamp ?? FIXED_TS
  const runCtx = createRunContext(timestamp)
  const runId = createRun(store)
  setRunInput(
    store,
    runId,
    'domain-direction',
    opts.domainDirection ?? 'adaptive traffic signal control research program',
  )

  const outcomes: StepOutcome[] = []
  for (const step of STEPS) {
    if (opts.stopBefore && step.id === opts.stopBefore) break
    const outcome = await driveStep(store, runId, step.id, {
      runCtx,
      timeoutMs: opts.timeoutMs,
      signal: opts.signal,
      executorOverride: opts.executorOverride,
      abstainComponents: opts.abstainComponents,
    })
    outcomes.push(outcome)
  }
  return { runId, steps: outcomes }
}

/** Drive every step from `fromStepId` (inclusive) through E2. Reuses runT19B's loop. */
export async function driveRemaining(
  store: ResearchRunStore,
  runId: string,
  runCtx: RunContext,
  fromStepId: string,
  opts: Omit<DriveOptions, 'stopBefore'> = {},
): Promise<RunResult> {
  const outcomes: StepOutcome[] = []
  let started = false
  for (const step of STEPS) {
    if (!started) {
      if (step.id !== fromStepId) continue
      started = true
    }
    const outcome = await driveStep(store, runId, step.id, {
      runCtx,
      timeoutMs: opts.timeoutMs,
      signal: opts.signal,
      executorOverride: opts.executorOverride,
      abstainComponents: opts.abstainComponents,
    })
    outcomes.push(outcome)
  }
  if (!started) throw new Error(`T19B drive: unknown fromStepId '${fromStepId}'`)
  return { runId, steps: outcomes }
}

export { rollback }
