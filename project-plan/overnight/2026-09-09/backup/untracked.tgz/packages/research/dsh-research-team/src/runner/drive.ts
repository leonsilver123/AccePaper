// @deepseek-ai/dsh-research-team — T19-B execution driver.
//
// Drives the real executor registry through the 16-step pipeline using the CORE
// engine as the single authority for state + gate adjudication:
//
//   createRun → setRunInput('domain-direction') → for each step in canonical order:
//     canStart (dependency guard) → startStep → runStep(registry executor)
//     → on success: build genuine gate verdicts (verdict.ts) → submitGateVerdict
//       (core `_adjudicate` is the SOLE gate adjudicator) → step leaves in_progress
//     → E2-submit (humanGate, empty gate): completeStep → 'gated' (await human approval)
//
// Discipline (spec §3/§7): the driver does NOT re-implement the gate, does NOT
// reinterpret outcomes, does NOT add a StepStatus, does NOT auto-approve E2, and
// preserves core runStep atomicity (rollback / new-attempt / timeout / error /
// artifact). Every artifact carries producer evidence (see registry.tagArtifact).
//
// Core `runStep` + `STEPS`/`STEP_BY_ID` are not re-exported from the public core
// entry, so they are imported read-only from core source relatively; all other
// engine functions come from the public `@deepseek-ai/dsh-research-core` entry.

import type {
  GateOutcome,
  ResearchRunStore,
  StepStatus,
  TrinityComponent,
} from '@deepseek-ai/dsh-research-core'
import {
  appendAuditEvent,
  canStart,
  completeStep,
  createRun,
  getArtifact,
  getRunSnapshot,
  rollback,
  setRunInput,
  startStep,
  submitGateVerdict,
} from '@deepseek-ai/dsh-research-core'
import { runStep } from '../../../../dsh-research-core/src/engine/pipeline.ts'

import {
  type ExecCtx,
  FIXED_TS,
  type RunContext,
  STEP_EXECUTOR_REGISTRY,
  STEPS,
  STEP_BY_ID,
  type Truthfulness,
} from './registry.ts'
import { buildStepVerdicts, type VerdictBuildCtx } from './verdict.ts'

/** Per-artifact producer evidence for one step. */
export interface StepArtifactEvidence {
  readonly slug: string
  readonly producedBy: string
}

/** Outcome of driving one step (auditable; includes producer/kind evidence). */
export interface StepOutcome {
  readonly stepId: string
  readonly status: StepStatus
  readonly attemptId: number
  readonly kind: Truthfulness | 'humanGate'
  readonly producer: string
  readonly outputSlugs: ReadonlyArray<string>
  readonly artifacts: ReadonlyArray<StepArtifactEvidence>
  readonly verdicts: Readonly<Record<string, GateOutcome>>
  readonly usedRealTool: boolean
  readonly executeError?: string
}

/** Full-run result. */
export interface RunResult {
  readonly runId: string
  readonly steps: ReadonlyArray<StepOutcome>
}

/** Per-step override / scenario hooks for the driver. */
export interface DriveOptions {
  readonly domainDirection?: string
  readonly timeoutMs?: number
  readonly signal?: AbortSignal
  /** Override the executor for selected steps (recovery / fault injection). */
  readonly executorOverride?: (stepId: string) => ((ctx: ExecCtx) => Promise<Record<string, unknown>> | Record<string, unknown>) | undefined
  /** Inject `abstained` for the given components of the given step (recovery hold). */
  readonly abstainComponents?: (stepId: string) => ReadonlyArray<TrinityComponent>
  readonly fixedTimestamp?: number
  /** Stop BEFORE driving this step (returns after its predecessors). */
  readonly stopBefore?: string
}

/** Drive exactly one step end-to-end (dependency guard → execute → gate → E2 stop). */
export async function driveStep(
  store: ResearchRunStore,
  runId: string,
  stepId: string,
  opts: {
    readonly runCtx: RunContext
    readonly timeoutMs?: number
    readonly signal?: AbortSignal
    readonly executorOverride?: (stepId: string) => ((ctx: ExecCtx) => Promise<Record<string, unknown>> | Record<string, unknown>) | undefined
    readonly abstainComponents?: (stepId: string) => ReadonlyArray<TrinityComponent>
  },
): Promise<StepOutcome> {
  const entry = STEP_EXECUTOR_REGISTRY.get(stepId)
  if (!entry) throw new Error(`T19B drive: no registry entry for '${stepId}'`)
  const stepDef = STEP_BY_ID.get(stepId)
  if (!stepDef) throw new Error(`T19B drive: unknown step '${stepId}'`)
  if (!canStart(store, runId, stepId)) {
    throw new Error(`T19B drive: step '${stepId}' cannot start — dependency order violated`)
  }

  const started = startStep(store, runId, stepId)
  const attemptId = started.attemptId

  // E2-submit: human gate, empty gate → completeStep leaves it 'gated' (awaiting
  // human approval). The driver NEVER auto-approves (spec §7).
  if (entry.humanGateStop) {
    const status = completeStep(store, runId, stepId)
    return {
      stepId,
      status,
      attemptId,
      kind: 'humanGate',
      producer: entry.producer,
      outputSlugs: [],
      artifacts: [],
      verdicts: {},
      usedRealTool: false,
    }
  }

  // Execute phase — core runStep keeps atomicity (rollback / attempt / timeout / error).
  const myExec = (opts.executorOverride?.(stepId) ?? entry.executor)
  const res = await runStep(store, runId, stepId, {
    executor: (coreCtx) =>
      myExec({
        runId: coreCtx.runId,
        stepId: coreCtx.stepId,
        attemptId: coreCtx.attemptId,
        ...(coreCtx.signal !== undefined ? { signal: coreCtx.signal } : {}),
        getInput: (slug: string) => getArtifact(store, runId, slug),
        runCtx: opts.runCtx,
      }),
    timeoutMs: opts.timeoutMs,
    signal: opts.signal,
  })

  // Execute did NOT succeed: step stays 'in_progress' (rollback-able), NO artifact,
  // NO gate adjudication. The caller asserts and then rolls back (recovery).
  if (res.status !== 'success') {
    return {
      stepId,
      status: 'in_progress',
      attemptId,
      kind: entry.kind,
      producer: entry.producer,
      outputSlugs: res.outputSlugs,
      artifacts: [],
      verdicts: {},
      usedRealTool: entry.kind !== 'fixture',
      executeError: res.error?.message,
    }
  }

  // Gate phase — build genuine verdicts and submit via core (single adjudication source).
  const verdicts: Record<string, GateOutcome> = {}
  if (stepDef.gate.length > 0) {
    const comps = opts.abstainComponents?.(stepId) ?? []
    const vctx: VerdictBuildCtx = {
      step: stepDef,
      attemptId,
      runCtx: opts.runCtx,
      abstain: new Set(comps),
    }
    const built = buildStepVerdicts(vctx)
    for (const v of built) {
      submitGateVerdict(store, runId, stepId, v)
      appendAuditEvent(store, runId, 'gate-verdict', stepId, attemptId, {
        t19b: true,
        component: v.component,
        outcome: v.outcome,
        evidence: v.evidence,
      })
      verdicts[v.component] = v.outcome
    }
  }

  const snap = getRunSnapshot(store, runId)
  const stepSnap = snap.steps[stepId]
  const status: StepStatus = stepSnap.status

  const artifacts: StepArtifactEvidence[] = []
  for (const slug of stepDef.outputs) {
    const value = getArtifact(store, runId, slug)
    const producedBy =
      value !== null && typeof value === 'object' && !Array.isArray(value)
        ? (value as Record<string, unknown>).__producer
        : undefined
    artifacts.push({
      slug,
      producedBy: typeof producedBy === 'string' ? producedBy : entry.producer,
    })
  }

  return {
    stepId,
    status,
    attemptId,
    kind: entry.kind,
    producer: entry.producer,
    outputSlugs: stepDef.outputs,
    artifacts,
    verdicts,
    usedRealTool: entry.kind !== 'fixture',
  }
}

/**
 * Drive a full 16-step run. Returns the per-step outcomes. `stopBefore` halts
 * before the named step (used by recovery scenarios to inject faults mid-run).
 */
export async function runT19B(
  store: ResearchRunStore,
  opts: DriveOptions = {},
): Promise<RunResult> {
  const timestamp = opts.fixedTimestamp ?? FIXED_TS
  const runCtx: RunContext = {
    predictionText: '',
    claimId: '',
    claimRef: '',
    timestamp,
  }
  const runId = createRun(store)
  setRunInput(
    store,
    runId,
    'domain-direction',
    opts.domainDirection ?? 'adaptive traffic signal control research program',
  )

  const outcomes: StepOutcome[] = []
  for (const step of STEPS) {
    if (opts.stopBefore && step.id === opts.stopBefore) break
    const outcome = await driveStep(store, runId, step.id, {
      runCtx,
      timeoutMs: opts.timeoutMs,
      signal: opts.signal,
      executorOverride: opts.executorOverride,
      abstainComponents: opts.abstainComponents,
    })
    outcomes.push(outcome)
  }
  return { runId, steps: outcomes }
}

/** Build a fresh cross-step context (claim / prediction wiring) for a run. */
export function createRunContext(timestamp: number = FIXED_TS): RunContext {
  return { predictionText: '', claimId: '', claimRef: '', timestamp }
}

/** Drive every step from `fromStepId` (inclusive) through E2. Reuses runT19B's loop. */
export async function driveRemaining(
  store: ResearchRunStore,
  runId: string,
  runCtx: RunContext,
  fromStepId: string,
  opts: Omit<DriveOptions, 'stopBefore'> = {},
): Promise<RunResult> {
  const outcomes: StepOutcome[] = []
  let started = false
  for (const step of STEPS) {
    if (!started) {
      if (step.id !== fromStepId) continue
      started = true
    }
    const outcome = await driveStep(store, runId, step.id, {
      runCtx,
      timeoutMs: opts.timeoutMs,
      signal: opts.signal,
      executorOverride: opts.executorOverride,
      abstainComponents: opts.abstainComponents,
    })
    outcomes.push(outcome)
  }
  if (!started) throw new Error(`T19B drive: unknown fromStepId '${fromStepId}'`)
  return { runId, steps: outcomes }
}

export { rollback }
